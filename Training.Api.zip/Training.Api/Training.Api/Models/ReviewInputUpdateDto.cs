﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Training.Api.Models
{
    public class ReviewInputUpdateDto
    {
        [Required]
        [MaxLength(50)]
        public string Comment { get; set; }
        
        [Range(1,5)]
        public int Rating { get; set; }
    }
}
