﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Training.Api.Models
{
    public class RestaurantDataStore
    {
        // Auto property inilizer syntax c# 6.0
        public static RestaurantDataStore Current { get; } = new RestaurantDataStore();

        public List<RestaurantDto> Restaurants { get; set; }


        public RestaurantDataStore()
        {
            Restaurants = new List<RestaurantDto>
            {
                new RestaurantDto{Id=1, Title="Mogli", City="Noida" ,
                    Reviews = new List<ReviewsDto>{
                        new ReviewsDto{Id=1, Comment="Good Food", Rating=4 },
                        new ReviewsDto{Id=2, Comment="Good Service", Rating=4 },
                        new ReviewsDto{Id=3, Comment="Quality Food", Rating=5 },
                        new ReviewsDto{Id=4, Comment=" Fast Service ", Rating=3 },

                    } },
                new RestaurantDto{Id=2, Title="YoChina", City="Delhi" ,
                    Reviews = new List<ReviewsDto>{
                        new ReviewsDto{Id=5, Comment="Good Food", Rating=1 },
                        new ReviewsDto{Id=6, Comment="Good Service", Rating=5 },
                        new ReviewsDto{Id=7, Comment="Quality Food", Rating=5 },
                        new ReviewsDto{Id=8, Comment=" Fast Service ", Rating=3 },

                    }},
                new RestaurantDto{Id=3, Title="Pind Baluchi", City="Noida" ,
                    Reviews = new List<ReviewsDto>{
                        new ReviewsDto{Id=9, Comment="Good Food", Rating=5 },
                        new ReviewsDto{Id=10, Comment="Good Service", Rating=4 },
                        new ReviewsDto{Id=11, Comment="Quality Food", Rating=5 },
                        new ReviewsDto{Id=12, Comment=" Fast Service ", Rating=5 },

                    }}
            };
        }
    }
}
