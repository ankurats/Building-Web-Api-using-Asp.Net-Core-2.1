﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Training.Api.Models;

namespace Training.Api.Controllers
{
    [Route("api/[controller]")]
    public class RestaurantController : Controller
    {
        [HttpGet]
        public IActionResult GetRestaurants()
        {
            return Ok(RestaurantDataStore.Current.Restaurants);
        }

        [HttpGet("{id}")]
        public IActionResult GetRestaurant(int id)
        {
            var restaurant = RestaurantDataStore.Current.Restaurants
                .FirstOrDefault(rest => rest.Id == id);

            if (restaurant == null)
               return NotFound();
            

            return Ok(restaurant);

        }
    }
}
