﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Training.Api.Models
{
    public class RestaurantDto
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string City { get; set; }

        public double AvgRating
        {
            get
            {
                return Reviews.Average(x => x.Rating);
                     
            }
        }

        public ICollection<ReviewsDto> Reviews { get; set; } = new List<ReviewsDto>();
    }
}
