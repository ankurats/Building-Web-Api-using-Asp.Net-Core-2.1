﻿using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Training.Api.Models;

namespace Training.Api.Controllers
{
    [Route("api/Restaurants")]
    public class ReviewController : Controller
    {
        private ILogger<ReviewController> _logger;

        public ReviewController( ILogger<ReviewController> logger)
        {
            this._logger = logger;
        }

        [HttpGet("{restaurantId}/[controller]")]
        public IActionResult GetReviews(int restaurantId)
        {
            var restaurant = RestaurantDataStore.Current.Restaurants
                .FirstOrDefault(x => x.Id == restaurantId);

            if (restaurant == null)
            {
                _logger.LogInformation($"Restaurant with id {restaurantId} wasn't found when accessing reveiws");
                return NotFound();
            }

            return Ok(restaurant);
        }


        [HttpGet("{restaurantId}/[controller]/{id}", Name = "GetReview")]
        public IActionResult GetReview(int restaurantId, int id)
        {
            var restaurant = RestaurantDataStore.Current.Restaurants
                .FirstOrDefault(x => x.Id == restaurantId);

            if (restaurant == null)
            {
                return NotFound();
            }

            var review = restaurant.Reviews.FirstOrDefault(re => re.Id == id);

            if (review == null)
                return NotFound();

            return Ok(review);
        }
        [HttpPost("{restId}/[controller]")]
        public IActionResult AddReviews(int restId, [FromBody] ReviewInputUpdateDto review)
        {
            if (review == null)
                BadRequest();

            if (!ModelState.IsValid)
                BadRequest(ModelState);

            var restaurant = RestaurantDataStore.Current.Restaurants.FirstOrDefault(x => x.Id == restId);

            if (restaurant == null)
                return NotFound();

            var maxReviewId = RestaurantDataStore.Current.Restaurants.SelectMany(r => r.Reviews).Max(p => p.Id);

            var newrReview = new ReviewsDto()
            {
                Id = ++maxReviewId,
                Comment = review.Comment,
                Rating = review.Rating
            };

            restaurant.Reviews.Add(newrReview);
            return CreatedAtAction("GetReview", new { restaurantId = restId, id = newrReview.Id }, value: newrReview);
        }

        [HttpPut("{restaurantId}/[controller]/{id}")]
        public IActionResult UpdateReview(int restaurantId, int id, [FromBody] ReviewInputUpdateDto review)
        {
            if (review == null)
                BadRequest();

            if (!ModelState.IsValid)
                BadRequest(ModelState);

            var restaurant = RestaurantDataStore.Current.Restaurants
                .FirstOrDefault(x => x.Id == restaurantId);

            if (restaurant == null)
                return NotFound();

            var reviewFromStore = restaurant.Reviews.FirstOrDefault(re => re.Id == id);

            if (reviewFromStore == null)
                return NotFound();


             reviewFromStore.Comment = review.Comment;
            reviewFromStore.Rating = review.Rating;

            return NoContent();
        }

        [HttpPatch("{restaurantId}/[controller]/{id}")]
        public IActionResult UpdateReview(int restaurantId, int id, [FromBody] JsonPatchDocument<ReviewInputUpdateDto> patchDoc)
        {
            if (patchDoc == null)
                BadRequest();


            var restaurant = RestaurantDataStore.Current.Restaurants
                .FirstOrDefault(x => x.Id == restaurantId);

            if (restaurant == null)
                return NotFound();

            var reviewFromStore = restaurant.Reviews.FirstOrDefault(re => re.Id == id);

            if (reviewFromStore == null)
                return NotFound();

            var reviewToPatch = new ReviewInputUpdateDto()
            {
                Comment = reviewFromStore.Comment,
                Rating = reviewFromStore.Rating
            };

            patchDoc.ApplyTo(reviewToPatch, ModelState);

            TryValidateModel(reviewToPatch);  // This should apply in last to shoe the error addign for model

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            reviewFromStore.Comment = reviewToPatch.Comment;
            reviewFromStore.Rating = reviewToPatch.Rating;

            return NoContent();
        }


        [HttpDelete("{restaurantId}/[controller]/{id}")]
        public IActionResult DeleteReview(int restaurantId, int id)
        {

            var restaurant = RestaurantDataStore.Current.Restaurants
                .FirstOrDefault(x => x.Id == restaurantId);

            if (restaurant == null)
                return NotFound();

            var reviewFromStore = restaurant.Reviews.FirstOrDefault(re => re.Id == id);

            if (reviewFromStore == null)
                return NotFound();

            restaurant.Reviews.Remove(reviewFromStore);

            return NoContent();

        }
    }
}